package com.example.techpalv2;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SplashScreen extends AppCompatActivity {

    private TextView name, slogan;
    private ImageView logo;
    private View toprightView1, toprightView2, toprightView3, topleftView1, topleftView2, topleftView3;
    private View bottomleftView1, bottomleftView2, bottomleftView3, bottomrightView1, bottomrightView2, bottomrightView3;

    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));


        //Splash Screen Start
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE);

        setContentView(R.layout.splashscreen_layout);

        name = findViewById(R.id.name);
        slogan = findViewById(R.id.slogan);
        logo = findViewById(R.id.logo);

        toprightView1 = findViewById(R.id.topright_view1);
        toprightView2 = findViewById(R.id.topright_view2);
        toprightView3 = findViewById(R.id.topright_view3);
        topleftView1 = findViewById(R.id.topleft_view1);
        topleftView2 = findViewById(R.id.topleft_view2);
        topleftView3 = findViewById(R.id.topleft_view3);

        bottomleftView1 = findViewById(R.id.bottomleft_view1);
        bottomleftView2 = findViewById(R.id.bottomleft_view2);
        bottomleftView3 = findViewById(R.id.bottomleft_view3);
        bottomrightView1 = findViewById(R.id.bottomright_view1);
        bottomrightView2 = findViewById(R.id.bottomright_view2);
        bottomrightView3 = findViewById(R.id.bottomright_view3);

        Animation logoAnimation = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.zoom_animation);
        Animation nameAnimation = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.zoom_animation);

        Animation toprightViewAnimation1 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topright_view);
        Animation toprightViewAnimation2 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topright_view);
        Animation toprightViewAnimation3 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topright_view);
        Animation topleftViewAnimation1 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topleft_view);
        Animation topleftViewAnimation2 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topleft_view);
        Animation topleftViewAnimation3 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.topleft_view);

        Animation bottomleftViewAnimation1 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomleft_view);
        Animation bottomleftViewAnimation2 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomleft_view);
        Animation bottomleftViewAnimation3 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomleft_view);
        Animation bottomrightViewAnimation1 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomright_view);
        Animation bottomrightViewAnimation2 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomright_view);
        Animation bottomrightViewAnimation3 = AnimationUtils.loadAnimation(SplashScreen.this, R.anim.bottomright_view);


        toprightView1.startAnimation(toprightViewAnimation1);
        topleftView1.startAnimation(topleftViewAnimation1);

        bottomleftView1.startAnimation(bottomleftViewAnimation1);
        bottomrightView1.startAnimation(bottomrightViewAnimation1);

        toprightViewAnimation1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                toprightView2.setVisibility(View.VISIBLE);
                topleftView2.setVisibility(View.VISIBLE);

                bottomleftView2.setVisibility(View.VISIBLE);
                bottomrightView2.setVisibility(View.VISIBLE);

                toprightView2.startAnimation(toprightViewAnimation2);
                topleftView2.startAnimation(topleftViewAnimation2);

                bottomleftView2.startAnimation(bottomleftViewAnimation2);
                bottomrightView2.startAnimation(bottomrightViewAnimation2);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        topleftViewAnimation1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // Animation start logic if needed
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                toprightView2.setVisibility(View.VISIBLE);
                topleftView2.setVisibility(View.VISIBLE);

                bottomleftView2.setVisibility(View.VISIBLE);
                bottomrightView2.setVisibility(View.VISIBLE);

                toprightView2.startAnimation(toprightViewAnimation2);
                topleftView2.startAnimation(topleftViewAnimation2);

                bottomleftView2.startAnimation(bottomleftViewAnimation2);
                bottomrightView2.startAnimation(bottomrightViewAnimation2);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // Animation repeat logic if needed
            }
        });

        toprightViewAnimation2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                toprightView3.setVisibility(View.VISIBLE);
                topleftView3.setVisibility(View.VISIBLE);

                bottomleftView3.setVisibility(View.VISIBLE);
                bottomrightView3.setVisibility(View.VISIBLE);

                toprightView3.startAnimation(toprightViewAnimation3);
                topleftView3.startAnimation(topleftViewAnimation3);

                bottomleftView3.startAnimation(bottomleftViewAnimation3);
                bottomrightView3.startAnimation(bottomrightViewAnimation3);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        topleftViewAnimation2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                toprightView3.setVisibility(View.VISIBLE);
                topleftView3.setVisibility(View.VISIBLE);

                bottomleftView3.setVisibility(View.VISIBLE);
                bottomrightView3.setVisibility(View.VISIBLE);

                toprightView3.startAnimation(toprightViewAnimation3);
                topleftView3.startAnimation(topleftViewAnimation3);

                bottomleftView3.startAnimation(bottomleftViewAnimation3);
                bottomrightView3.startAnimation(bottomrightViewAnimation3);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        toprightViewAnimation3.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                logo.setVisibility(View.VISIBLE);
                logo.startAnimation(logoAnimation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        logoAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                name.setVisibility(View.VISIBLE);
                name.startAnimation(nameAnimation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        nameAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                slogan.setVisibility(View.VISIBLE);
                final String animatetxt = slogan.getText().toString();
                slogan.setText("");
                count = 0;

                new CountDownTimer(animatetxt.length() * 100, 100) {

                    @Override
                    public void onTick(long m) {

                        slogan.setText(slogan.getText().toString() + animatetxt.charAt(count));
                        count++;

                    }

                    @Override
                    public void onFinish() {

                        // Start the DashboardActivity
                        Intent intent = new Intent(SplashScreen.this, Dashboardv2.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish(); // Finish the splash screen activity
                    }
                }.start();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {


            }
        });
    }
}