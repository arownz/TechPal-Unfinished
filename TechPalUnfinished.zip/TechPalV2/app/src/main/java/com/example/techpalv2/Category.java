package com.example.techpalv2;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Category extends AppCompatActivity {

    private CardView free,freemium,premium,text,image,video,audio,codes,design,education,chatbot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        setContentView(R.layout.category_layout);


        free = (CardView) findViewById(R.id.c1);
        free.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(getApplicationContext(), free.class);
                startActivity(i1);
            }
        });
        freemium = (CardView) findViewById(R.id.c2);
        freemium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getApplicationContext(), freemium.class);
                startActivity(i2);
            }
        });
        premium = (CardView) findViewById(R.id.c3);
        premium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3 = new Intent(getApplicationContext(), premium.class);
                startActivity(i3);
            }
        });
        text = (CardView) findViewById(R.id.c4);
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4 = new Intent(getApplicationContext(), text.class);
                startActivity(i4);
            }
        });
        image = (CardView) findViewById(R.id.c5);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i5 = new Intent(getApplicationContext(), image.class);
                startActivity(i5);
            }
        });
        video = (CardView) findViewById(R.id.c6);
        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i6 = new Intent(getApplicationContext(), video.class);
                startActivity(i6);
            }
        });
        audio = (CardView) findViewById(R.id.c7);
        audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i7 = new Intent(getApplicationContext(), audio.class);
                startActivity(i7);
            }
        });
        codes = findViewById(R.id.c8);
        codes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i8 = new Intent(getApplicationContext(), code.class);
                startActivity(i8);
            }
        });
        design = (CardView) findViewById(R.id.c9);
        design.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i9 = new Intent(getApplicationContext(), design.class);
                startActivity(i9);
            }
        });
        education = (CardView) findViewById(R.id.c10);
        education.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i10 = new Intent(getApplicationContext(), education.class);
                startActivity(i10);
            }
        });
        chatbot = (CardView) findViewById(R.id.c11);
        chatbot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i11 = new Intent(getApplicationContext(), chatbot.class);
                startActivity(i11);
            }
        });

        //Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavView);
        bottomNavigationView.setSelectedItemId(R.id.navCategorizer);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.navDashboard) {
                    startActivity(new Intent(getApplicationContext(), Dashboardv2.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (id == R.id.navCategorizer) {
                    startActivity(new Intent(getApplicationContext(), Category.class));
                    overridePendingTransition(0, 0);
                    return true;
                }

                if (id == R.id.navAbout) {
                    startActivity(new Intent(getApplicationContext(), About.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                return false;
            }
        });
    }
    @Override
    public void onBackPressed () {
        // Call super onBackPressed method
        super.onBackPressed();

        // Handle back press
        startActivity(new Intent(getApplicationContext(), Dashboardv2.class));
        overridePendingTransition(0, 0);
    }
}