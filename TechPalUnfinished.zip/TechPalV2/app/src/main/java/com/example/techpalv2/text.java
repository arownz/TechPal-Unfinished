package com.example.techpalv2;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class text extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerViewAdapter adapter;
    private List<CardViewItem> dataList;
    private EditText searcheditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        setContentView(R.layout.activity_text);

        recyclerView = findViewById(R.id.recyclerView);
        searcheditText = findViewById(R.id.searchingv2);

        // Clear search
        EditText searchingv2 = findViewById(R.id.searchingv2);

        // Add text change listener to EditText
        searchingv2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Update visibility of the clear drawable when text changes
                updateClearButtonVisibility(searchingv2);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Set OnClickListener for clear drawable
        searchingv2.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                // Check if touch event is on the clear drawable
                if (event.getRawX() >= (searchingv2.getRight() - searchingv2.getCompoundDrawables()[2].getBounds().width())) {
                    // Clear text
                    searchingv2.setText("");
                    return true;
                }
            }
            return false;
        });

        // Update visibility of the clear drawable initially
        updateClearButtonVisibility(searchingv2);

        // Create a list of CardViewItem objects with image, title, description, and activity class
        dataList = new ArrayList<>();
        dataList.add(new CardViewItem(R.drawable.writesonic1, "Whitesonic", "AI 1", card1.class));
        dataList.add(new CardViewItem(R.drawable.rytr1, "Rytr", "AI 2", card2.class));
        dataList.add(new CardViewItem(R.drawable.notion1, "Notion", "AI 4", card4.class));
        dataList.add(new CardViewItem(R.drawable.tome, "Tome", "AI 5", card5.class));
        // Add more items as needed

        adapter = new RecyclerViewAdapter(dataList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        searcheditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Call a method to filter the data based on the search query
                filterData(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        //Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavView);
        bottomNavigationView.setSelectedItemId(R.id.navCategorizer);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.navDashboard) {
                    startActivity(new Intent(getApplicationContext(), Dashboardv2.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (id == R.id.navCategorizer) {
                    startActivity(new Intent(getApplicationContext(), Category.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                if (id == R.id.navAbout) {
                    startActivity(new Intent(getApplicationContext(), About.class));
                    overridePendingTransition(0, 0);
                    return true;
                }
                return false;
            }
        });
    }

    // Method to update visibility of the clear drawable
    private void updateClearButtonVisibility(EditText editText) {
        Drawable[] compoundDrawables = editText.getCompoundDrawables();
        Drawable rightDrawable = compoundDrawables[2]; // Assuming clear drawable is at index 2
        if (editText.getText().length() > 0) {
            // Show clear drawable
            rightDrawable.setVisible(true, false);
        } else {
            // Hide clear drawable
            rightDrawable.setVisible(false, false);
        }
    }

    private void filterData(String query) {
        List<CardViewItem> filteredList = new ArrayList<>();
        for (CardViewItem item : dataList) {
            if (item.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                    item.getDescription().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.setData(filteredList);
    }

    private class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

        private List<CardViewItem> dataList;

        public RecyclerViewAdapter(List<CardViewItem> dataList) {
            this.dataList = dataList;
        }

        public void setData(List<CardViewItem> dataList) {
            this.dataList = dataList;
            notifyDataSetChanged();
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_card_view_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final CardViewItem item = dataList.get(position);
            holder.imageView.setImageResource(item.getImageResource());
            holder.titleTextView.setText(item.getTitle());
            holder.descriptionTextView.setText(item.getDescription());

            // Set click listener for the card view
            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Launch the respective activity based on the card clicked
                    Intent intent = new Intent(text.this, item.getActivityClass());
                    startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            CardView cardView;
            ImageView imageView;
            TextView titleTextView;
            TextView descriptionTextView;

            ViewHolder(View itemView) {
                super(itemView);
                cardView = itemView.findViewById(R.id.card_view);
                imageView = itemView.findViewById(R.id.imageView);
                titleTextView = itemView.findViewById(R.id.titleTextView);
                descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
            }
        }
    }
}